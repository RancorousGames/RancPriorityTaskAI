﻿#include "RAIBlueprintLibrary.h"
#include "Tasks/AITask_MoveTo.h"

UAITask_MoveTo* URAIBlueprintLibrary::MoveToLocationOrActorAndWait(ARAIController* Controller, FVector GoalLocation, AActor* GoalActor, float AcceptanceRadius, bool bUseContinuousGoalTracking)
{
	
	return UAITask_MoveTo::AIMoveTo(Controller, GoalLocation, GoalActor, AcceptanceRadius);
}